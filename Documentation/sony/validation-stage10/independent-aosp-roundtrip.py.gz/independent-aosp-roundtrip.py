#!/usr/bin/env python3
"""Independent AOSP unpack + byte/hash/layout checks; no repository imports.

All extraction output is private. Software checks never qualify Sony firmware
or physical hardware. --reference-only inspects the unchanged supplied source;
it permits its known unsafe literal layout and security metadata for analysis.
"""
import argparse
import hashlib
import json
import lzma
from pathlib import Path
import struct
import subprocess
import sys
import zlib

TOOLS = Path(__file__).resolve().parent
UNPACKER = TOOLS / 'unpack_bootimg.py'
AOSP_SHA256 = 'a9d260978a63bd06a24b6347e7dee8a28ff96639793caea15dff6aa491316308'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def align(value, page):
    return (value + page - 1) // page * page

def overlap(a, b):
    return a[0] < b[0] + b[1] and b[0] < a[0] + a[1]

def header(data):
    assert len(data) >= 1632 and data[:8] == b'ANDROID!', 'Android v0 magic/header'
    ks, ka, rs, ra, ss, sa, ta, page, version, osv = struct.unpack_from('<10I', data, 8)
    assert version == 0, 'only source-qualified legacy QCOM v0 supported here'
    assert page >= 2048 and not page & (page - 1) and page >= 1632
    ko = page
    ro = ko + align(ks, page)
    so = ro + align(rs, page)
    end = so + align(ss, page)
    assert end == len(data), 'compact image extent must match page-aligned sections'
    kernel, ramdisk, second = data[ko:ko+ks], data[ro:ro+rs], data[so:so+ss]
    assert len(kernel) == ks and len(ramdisk) == rs and len(second) == ss
    assert not any(data[1632:page])
    for start, size in [(ko, ks), (ro, rs), (so, ss)]:
        assert not any(data[start+size:start+align(size, page)]), 'nonzero page padding'
    digest = hashlib.sha1()
    for section in [kernel, ramdisk, second]:
        digest.update(section)
        digest.update(struct.pack('<I', len(section)))
    aosp_id = digest.hexdigest()
    digest.update(struct.pack('<I', 0))  # actual reference legacy QCOM dt_size=0
    qcom_id = digest.digest()
    assert data[576:596] == qcom_id and data[596:608] == bytes(12), 'legacy QCOM v0 ID'
    cmdline = (data[64:576].split(b'\0', 1)[0] +
               data[608:1632].split(b'\0', 1)[0]).decode('utf-8')
    return dict(kernel_size=ks, kernel_addr=ka, ramdisk_size=rs, ramdisk_addr=ra,
                second_size=ss, second_addr=sa, tags_addr=ta, page_size=page,
                header_version=version, os_version_word=osv, kernel_offset=ko,
                ramdisk_offset=ro, second_offset=so, compact_extent=end,
                header_id=qcom_id.hex(), strict_aosp_v0_id=aosp_id), (kernel, ramdisk, second), cmdline

def fdt(data):
    assert len(data) >= 40
    magic, total, st, strings, reserve, version, compatible, cpu, ssz, stsz = struct.unpack_from('>10I', data)
    assert magic == 0xd00dfeed and total == len(data)
    assert st + stsz <= total and strings + ssz <= total
    block, names = data[st:st+stsz], data[strings:strings+ssz]
    stack, props, pos = [], {}, 0
    while pos < len(block):
        token, = struct.unpack_from('>I', block, pos)
        pos += 4
        if token == 1:
            end = block.index(0, pos)
            name = block[pos:end].decode('utf-8')
            pos = align(end + 1, 4)
            path = '/' if not stack else stack[-1].rstrip('/') + '/' + name
            stack.append(path)
            assert path not in props
            props[path] = {}
        elif token == 2:
            assert stack
            stack.pop()
        elif token == 3:
            size, nameoff = struct.unpack_from('>II', block, pos)
            pos += 8
            assert stack and pos + size <= len(block) and nameoff < len(names)
            end = names.index(0, nameoff)
            name = names[nameoff:end].decode('utf-8')
            assert name not in props[stack[-1]]
            props[stack[-1]][name] = block[pos:pos+size]
            pos = align(pos + size, 4)
        elif token == 4:
            continue
        elif token == 9:
            assert not stack
            break
        else:
            raise AssertionError('invalid FDT token')
    else:
        raise AssertionError('missing FDT end')
    resv = []
    while reserve + 16 <= total:
        address, size = struct.unpack_from('>QQ', data, reserve)
        reserve += 16
        if not address and not size:
            break
        resv.append((address, size))
    else:
        raise AssertionError('missing reservation end')
    identity = {}
    for key in ['qcom,msm-id', 'qcom,board-id', 'qcom,pmic-id']:
        value = props['/'][key]
        assert len(value) % 4 == 0
        identity[key] = list(struct.unpack('>' + 'I'*(len(value)//4), value))
    reserved = props.get('/reserved-memory', {})
    assert reserved.get('#address-cells') == struct.pack('>I', 2)
    assert reserved.get('#size-cells') == struct.pack('>I', 2)
    for path, node in props.items():
        if path.startswith('/reserved-memory/') and 'reg' in node:
            value = node['reg']
            assert len(value) % 16 == 0
            for offset in range(0, len(value), 16):
                resv.append(struct.unpack_from('>QQ', value, offset))
    memory = props.get('/memory', {}).get('reg', b'')
    return identity, resv, bool(any(memory))

def split_kernel(data):
    assert data[:2] == b'\x1f\x8b', 'expected source gzip kernel'
    dec = zlib.decompressobj(16 + zlib.MAX_WBITS)
    raw = dec.decompress(data, 512*1024*1024)
    assert dec.eof and not dec.unconsumed_tail
    raw += dec.flush()
    assert raw[56:60] == b'ARM\x64' and len(raw) >= 64
    text_offset, image_size, flags = struct.unpack_from('<QQQ', raw, 8)
    assert image_size and image_size >= len(raw)
    tail, dtbs, offset = dec.unused_data, [], len(data) - len(dec.unused_data)
    while tail:
        assert len(tail) >= 40 and tail[:4] == b'\xd0\x0d\xfe\xed', 'DTB append format/order'
        size, = struct.unpack_from('>I', tail, 4)
        assert size >= 40 and size <= len(tail)
        tree = tail[:size]
        ids, reserved, memory_proved = fdt(tree)
        dtbs.append(dict(offset=offset, size=size, sha256=sha(tree), identity=ids,
                         fixed_reservations=reserved, memory_bank_present=memory_proved))
        tail, offset = tail[size:], offset + size
    assert len(dtbs) == 4, 'four mandatory DTBs'
    return raw, dict(text_offset=text_offset, image_size=image_size, flags=flags,
                     file_size=len(raw), sha256=sha(raw)), dtbs

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--kernel', type=Path, required=True)
    parser.add_argument('--ramdisk', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--reference-image', type=Path)
    parser.add_argument('--layout-profile', type=Path)
    parser.add_argument('--uncompressed-image', type=Path)
    parser.add_argument('--reference-only', action='store_true')
    parser.add_argument('--partition-size', type=lambda x: int(x, 0))
    args = parser.parse_args()
    assert sha(UNPACKER.read_bytes()) == AOSP_SHA256, 'official AOSP tool changed'
    assert not args.out.exists(), 'fresh private round-trip output required'
    args.out.mkdir(parents=True, mode=0o700)
    image = args.image.read_bytes()
    before = sha(image)
    info, sections, cmdline = header(image)
    with (args.out/'official-aosp-unpack.log').open('w') as log:
        subprocess.run([sys.executable, str(UNPACKER), '--boot_img', str(args.image),
                        '--out', str(args.out)], stdout=log, stderr=subprocess.STDOUT, check=True)
    assert not info['second_size'], 'unexpected second bootloader'
    assert sections[0] == args.kernel.read_bytes() == (args.out/'kernel').read_bytes()
    assert sections[1] == args.ramdisk.read_bytes() == (args.out/'ramdisk').read_bytes()
    assert sections[1].startswith(b'\xfd7zXZ\x00'), 'working XZ ramdisk compression changed'
    initramfs = lzma.decompress(sections[1])
    assert initramfs.startswith(b'070701') and b'TRAILER!!!\x00' in initramfs
    raw, arm64, dtbs = split_kernel(sections[0])
    if args.uncompressed_image:
        assert raw == args.uncompressed_image.read_bytes()
    if args.reference_image:
        ref_info, ref_sections, _ = header(args.reference_image.read_bytes())
        _, _, reference_dtbs = split_kernel(ref_sections[0])
        assert [x['identity'] for x in dtbs] == [x['identity'] for x in reference_dtbs], 'DTB tuple order changed'
        assert sections[1] == ref_sections[1], 'working LOS21 ramdisk changed'
        assert info['page_size'] == ref_info['page_size']
        assert info['os_version_word'] == ref_info['os_version_word']
        if args.partition_size is None and not args.reference_only:
            assert len(image) <= args.reference_image.stat().st_size, 'candidate exceeds conservative working-image bound'
    if args.partition_size is not None:
        assert args.partition_size > 0 and len(image) <= args.partition_size
    forbidden = [word for word in cmdline.split() if word in
                 ['androidboot.selinux=permissive', 'selinux=0', 'enforcing=0']]
    extent = max(len(raw), arm64['image_size'])
    kernel_region = (info['kernel_addr'], extent)
    initrd_region = (info['ramdisk_addr'], info['ramdisk_size'])
    literal_overlap = overlap(kernel_region, initrd_region)
    dt_checks = []
    if not args.reference_only:
        assert not forbidden, 'new image must not disable SELinux enforcement'
        assert args.layout_profile, 'source-backed explicit layout profile required'
        profile = json.loads(args.layout_profile.read_text())
        for key in ['kernel_addr', 'ramdisk_addr', 'tags_addr', 'page_size']:
            assert info[key] == profile[key], 'header destination/profile mismatch: ' + key
        assert arm64['text_offset'] == profile['arm64_text_offset']
        assert (info['kernel_addr'] - arm64['text_offset']) % (2*1024*1024) == 0
        assert not literal_overlap
        for tree in dtbs:
            need = tree['size'] + profile['source_dtb_pad_bytes'] + len(cmdline.encode())
            assert need <= profile['dtb_workspace_capacity_before_ramdisk']
            tag_region = (info['tags_addr'], need)
            assert not overlap(kernel_region, tag_region) and not overlap(initrd_region, tag_region)
            for reserved in tree['fixed_reservations']:
                assert not any(overlap(reserved, r) for r in [kernel_region, initrd_region, tag_region])
            dt_checks.append(dict(sha256=tree['sha256'], workspace_required=need, overlaps=False))
        scratch_input = (profile['scratch_addr'] + info['page_size'], info['kernel_size'])
        scratch_output = (profile['scratch_addr'] + info['compact_extent'] + info['page_size'], len(raw))
        assert not overlap(scratch_input, scratch_output)
        assert scratch_output[0] + scratch_output[1] <= profile['scratch_addr'] + profile['scratch_capacity']
    assert sha(args.image.read_bytes()) == before, 'input image was modified'
    report = dict(independent_official_aosp_unpack=True,
                  aosp_tool_sha256=AOSP_SHA256, checker_sha256=sha(Path(__file__).read_bytes()),
                  image_sha256=before, image_size=len(image), header=info,
                  kernel_matches_expected_and_aosp_extract=True, ramdisk_matches_expected_and_aosp_extract=True,
                  kernel_sha256=sha(sections[0]), ramdisk_sha256=sha(sections[1]),
                  ramdisk_unchanged_from_reference=bool(args.reference_image),
                  initramfs_sha256=sha(initramfs), initramfs_size=len(initramfs),
                  supplied_partition_limit=args.partition_size,
                  actual_partition_size_proved=False,
                  conservative_reference_extent_bound_applied=bool(args.reference_image and not args.partition_size and not args.reference_only), arm64=arm64,
                  dtbs=[{k:v for k,v in t.items() if k!='fixed_reservations'} for t in dtbs],
                  source_profile_dtb_layout_checks=dt_checks, reference_only=args.reference_only,
                  reference_literal_kernel_initrd_overlap=literal_overlap,
                  reference_security_metadata_detected=bool(forbidden), input_unchanged=True,
                  hardware_verified=False, sony_firmware_compatible_proved=False,
                  boot_test_ready=False, booted=False)
    args.report.write_text(json.dumps(report, indent=2)+'\n')
    print('PASS: official AOSP extraction, exact source components, QCOM v0 ID, gzip/ARM64/4-DTB checks')
    if args.reference_only:
        print('Reference-only: original literal overlaps/security metadata retained as observations')
    else:
        print('PASS: declared source-profile placement; actual Sony firmware/hardware remains unverified')

if __name__ == '__main__':
    main()
